package com.example.pemesanan_tiket_pesawat

import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    var sql: SQLiteDatabase? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sql = DatabaseHelper(this).writableDatabase

        // data asal
        val asalYogya = findViewById<RadioButton>(R.id.asalJogja)
        val asalJakarta = findViewById<RadioButton>(R.id.asalJakarta)
        val asalBali = findViewById<RadioButton>(R.id.asalBali)

        // data tujuan
        val tujuanYogya = findViewById<RadioButton>(R.id.asalJogja)
        val tujuanJakarta = findViewById<RadioButton>(R.id.asalJakarta)
        val tujuanBali = findViewById<RadioButton>(R.id.asalBali)
        val btnNext1 = findViewById<Button>(R.id.btnNext1)

        btnNext1.setOnClickListener {
            // data tanggal
            val tgl = findViewById<EditText>(R.id.tanggal)
            val bulan = findViewById<EditText>(R.id.bulan).text
            val tahun = findViewById<EditText>(R.id.tahun)

            var kotaAsal = ""
            var kotaTujuan = ""
            var tanggal = "${tgl} - ${bulan.toString()} - ${tahun} "

            if(asalYogya.isChecked){
                kotaAsal = "Yogyakarta"
            }
            if(asalBali.isChecked) {
                kotaAsal = "Bali"
            }
            if(asalJakarta.isChecked) {
                kotaAsal = "Jakarta"
            }
            if(tujuanYogya.isChecked) {
                if(asalYogya.isChecked) {
                    Toast.makeText(this,"Pilih kota asal dan tujuan dengan tepat", Toast.LENGTH_SHORT).show()
                }
                kotaTujuan = "Yogyakarta"
            }

            if(tujuanJakarta.isChecked) {
                if(asalJakarta.isChecked) {
                    Toast.makeText(this,"Pilih kota asal dan tujuan dengan tepat", Toast.LENGTH_SHORT).show()
                }
                kotaTujuan = "Jakarta"
            }

            if(tujuanBali.isChecked) {
                if(asalBali.isChecked) {
                    Toast.makeText(this,"Pilih kota asal dan tujuan dengan tepat", Toast.LENGTH_SHORT).show()
                }
                kotaTujuan = "Bali"
            }
            simpan(kotaAsal,kotaTujuan,tanggal)

            val i = Intent(this,DetailPenerbanganActivity::class.java)
            startActivity(i)
            finish()
        }
    }


    fun simpan(kotaAsal: String, kotaTujuan: String, tanggal: String) {
        val values = ContentValues().apply {
            put(DatabaseContract.Tiket.COLUMN_NAME_ASAL,kotaAsal)
            put(DatabaseContract.Tiket.COLUMN_NAME_TUJUAN,kotaTujuan)
            put(DatabaseContract.Tiket.COLUMN_NAME_TANGGAL,tanggal)
        }
        sql?.insert(DatabaseContract.Tiket.TABLE_NAME,null,values)
    }
}