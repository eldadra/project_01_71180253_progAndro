package com.example.pemesanan_tiket_pesawat

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context): SQLiteOpenHelper(context, "myDaatabase", null, 1) {
    override fun onCreate(sql: SQLiteDatabase?) {
        sql?.execSQL(DatabaseContract.Tiket.SQL_CREATE_TABLE)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        TODO("Not yet implemented")
    }

}