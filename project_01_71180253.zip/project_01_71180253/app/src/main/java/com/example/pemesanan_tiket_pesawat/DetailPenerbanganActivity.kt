package com.example.pemesanan_tiket_pesawat

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailPenerbanganActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_penerbangan)
    }
}