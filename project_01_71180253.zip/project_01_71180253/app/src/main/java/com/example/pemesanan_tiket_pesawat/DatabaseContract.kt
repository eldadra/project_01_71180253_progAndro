package com.example.pemesanan_tiket_pesawat

import android.provider.BaseColumns

class DatabaseContract {
    object Tiket: BaseColumns {
        const val TABLE_NAME = "tiket"
        const val COLUMN_NAME_ASAL = "asal"
        const val COLUMN_NAME_TUJUAN = "tujuan"
        const val COLUMN_NAME_TANGGAL = "tanggal"
        const val COLUMN_NAME_JAM = "jam"
        const val COLUMN_NAME_KELAS = "kelas"

        const val SQL_CREATE_TABLE = "CREATE TABLE ${TABLE_NAME} (" +
                "${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT," +
                "${COLUMN_NAME_ASAL} TEXT," +
                "${COLUMN_NAME_TUJUAN} TEXT," +
                "${COLUMN_NAME_TANGGAL} TEXT," +
                "${COLUMN_NAME_JAM} INTEGER," +
                "${COLUMN_NAME_KELAS} TEXT" +
                ")"

        const val SQL_DELETE_TABLE = "DROP TABLE IF EXISTS ${TABLE_NAME}"
    }
}